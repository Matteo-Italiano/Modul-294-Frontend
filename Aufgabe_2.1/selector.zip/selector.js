Neuveröffentlichungen = document.querySelectorAll('ul')[0].children;

SecondBestSeller = document.querySelectorAll('ul')[1].children[1];

LastFreeToPlay = document.querySelectorAll('ul')[2].lastElementChild;

Bestseller = document.querySelectorAll('ul')[1].children[0];

h1Element = document.querySelector('h1');

gameOfTheDay = document.getElementById('game-of-the-day')

AllSaleElements = document.querySelectorAll('.sale');